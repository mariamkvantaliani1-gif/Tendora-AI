import os
import streamlit as st
from agent import build_graph

st.set_page_config(page_title="Tendora AI", page_icon="⚡")
st.title("Tendora AI — ახალი ვერსია")

# გასაღების ჩაწერა პირდაპირ აპლიკაციიდან, თუ env/secrets-ში არ არის
current_key = os.getenv("GROQ_API_KEY", "").strip()
if not current_key:
    try:
        current_key = str(st.secrets.get("GROQ_API_KEY", "")).strip()
    except Exception:
        current_key = ""

input_key = st.sidebar.text_input("GROQ_API_KEY", value=current_key, type="password")
if input_key.strip():
    os.environ["GROQ_API_KEY"] = input_key.strip()

if "graph" not in st.session_state:
    st.session_state.graph = build_graph()

topic = st.text_input("შეიყვანე თემა:")

if st.button("გენერაცია"):
    if not os.getenv("GROQ_API_KEY"):
        st.error("გთხოვთ შეიყვანოთ GROQ_API_KEY (მარცხენა პანელში ან Streamlit Secrets-ში).")
    elif not topic.strip():
        st.warning("შეიყვანე თემა.")
    else:
        try:
            out = st.session_state.graph.invoke(
                {"topic": topic.strip()},
                config={"configurable": {"thread_id": "tendora-session-1"}},
            )
            st.subheader("შედეგი")
            st.write(out["draft"])
        except Exception as exc:
            st.error(f"შეცდომა: {exc}")
