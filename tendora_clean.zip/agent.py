import os
from typing import TypedDict
from langchain_groq import ChatGroq
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver


class State(TypedDict):
    topic: str
    draft: str


def resolve_groq_key(explicit_key: str | None = None) -> str | None:
    if explicit_key and explicit_key.strip():
        return explicit_key.strip()

    env_key = os.getenv("GROQ_API_KEY")
    if env_key and env_key.strip():
        return env_key.strip()

    try:
        import streamlit as st
        if "GROQ_API_KEY" in st.secrets and str(st.secrets["GROQ_API_KEY"]).strip():
            return str(st.secrets["GROQ_API_KEY"]).strip()
    except Exception:
        pass

    return None


def create_draft_node(state: State) -> dict:
    api_key = resolve_groq_key()
    if not api_key:
        raise ValueError("GROQ_API_KEY არ არის მითითებული. შეიყვანეთ გასაღები გვერდზე ან Secrets-ში.")

    llm = ChatGroq(
        model="llama-3.3-70b-versatile",
        temperature=0.2,
        api_key=api_key,
    )
    res = llm.invoke(f"მოკლედ და გასაგებად მოამზადე კონტენტი თემაზე: {state['topic']}")
    return {"draft": res.content}


def build_graph():
    workflow = StateGraph(State)
    workflow.add_node("create_draft", create_draft_node)
    workflow.add_edge(START, "create_draft")
    workflow.add_edge("create_draft", END)
    return workflow.compile(checkpointer=MemorySaver())
